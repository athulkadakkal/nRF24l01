multiceiver_demo.py
====================

.. literalinclude:: ../../../../examples_linux/multiceiver_demo.py
    :language: python
    :caption: examples_linux/multiceiver_demo.py
    :linenos:
    :lineno-match:
